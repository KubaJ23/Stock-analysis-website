package com.stockViewer.stockViewer.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.stockViewer.stockViewer.Global;
import com.stockViewer.stockViewer.models.*;
import com.stockViewer.stockViewer.repositories.SessionRepo;
import com.stockViewer.stockViewer.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class UserService {
    private final Gson gson = new Gson();
    @Autowired
    UserRepo userRepo;
    @Autowired
    SessionRepo sessionRepo;

    public static List<String> getUserStockList(User requestingUser) {
        return requestingUser.getStocks();
    }

    public Boolean changeUserPassword(ChangePasswordForm changePasswordForm) {
        User user = userRepo.findByEmail(changePasswordForm.getEmail());
        if (user == null) return false;
        if (!user.getPassword().equals(Integer.toString(changePasswordForm.getOldpassword().hashCode()))) return false;
        user.setPassword(Integer.toString(changePasswordForm.getNewpassword().hashCode()));
        userRepo.save(user);
        return true;
    }

    public void addStockForUser(User user, String stockSymbol) {
        for (String stock : user.getStocks()) {
            if (stock.equalsIgnoreCase(stockSymbol)) {
                return;
            }
        }
        user.getStocks().add(stockSymbol.toUpperCase());
        userRepo.save(user);
    }

    public StockHistoricalPrice getStockHistoricalPrice(String stockSymbol) throws URISyntaxException, IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder().uri(new URI(Global.stockApi + "/api/v3/historical-price-full/%s?apikey=%s".formatted(stockSymbol, Global.apiKey))).build();
        HttpResponse<String> response;
        try (HttpClient client = HttpClient.newHttpClient()) {
            response = client.send(request, BodyHandlers.ofString());
        }
        if (response.statusCode() != 200) {
            return null;
        }
        System.out.printf("Got stock historical price: \n%s\n", response);
        return gson.fromJson(response.body(), StockHistoricalPrice.class);
    }

    public List<CompanySearchItem> searchCompany(String stockSymbol) throws URISyntaxException, IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder().uri(new URI(Global.stockApi + "/api/v3/search?query=%s&apikey=%s".formatted(stockSymbol, Global.apiKey))).build();
        HttpResponse<String> response;
        try (HttpClient client = HttpClient.newHttpClient()) {
            response = client.send(request, BodyHandlers.ofString());
        }
        Type type = new TypeToken<List<CompanySearchItem>>() {
        }.getType();
        return gson.fromJson(response.body(), type);
    }

    public void deleteStockForUser(User requestingUser, String stockName) {
        requestingUser.setStocks(requestingUser.getStocks().stream().filter((stock) -> !stock.equalsIgnoreCase(stockName)).toList());
        userRepo.save(requestingUser);
    }

    public List<CompanyProfile> getCompanyProfile(String stockName) throws URISyntaxException, IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder().uri(new URI(Global.stockApi + "/api/v3/profile/%s?apikey=%s".formatted(stockName, Global.apiKey))).build();
        HttpResponse<String> response;
        try (HttpClient client = HttpClient.newHttpClient()) {
            response = client.send(request, BodyHandlers.ofString());
        }
        Type type = new TypeToken<List<CompanyProfile>>() {
        }.getType();
        System.out.printf("Got company profile data: \n%s\n", response);
        return gson.fromJson(response.body(), type);
    }

    public boolean deleteSession(User user) {
        sessionRepo.deleteByUseremail(user.getEmail());
        return true;
    }
}
