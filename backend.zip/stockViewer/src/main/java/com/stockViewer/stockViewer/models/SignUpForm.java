package com.stockViewer.stockViewer.models;

import lombok.Data;

@Data
public class SignUpForm {
    private String email;
    private String password;
}
