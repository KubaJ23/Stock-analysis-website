package com.stockViewer.stockViewer.services;

import com.stockViewer.stockViewer.models.Session;
import com.stockViewer.stockViewer.models.User;
import com.stockViewer.stockViewer.repositories.SessionRepo;
import com.stockViewer.stockViewer.repositories.UserRepo;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class LoginService {
    @Autowired
    UserRepo userRepo;
    @Autowired
    SessionRepo sessionRepo;

    public Boolean saveUser(User user) {
        User existingUser = userRepo.findByEmail(user.getEmail());
        Pattern pattern = Pattern.compile("\\s");
        Matcher emailMatcher = pattern.matcher(user.getEmail());
        Matcher passwordMatcher = pattern.matcher(user.getPassword());
        if (existingUser != null
                || user.getEmail().length() < 3
                || user.getPassword().length() < 3
                || emailMatcher.find()
                || passwordMatcher.find())
            return false;
        userRepo.save(new User(user.getEmail(), Integer.toString(user.getPassword().hashCode()), new ArrayList<>()));
        return true;
    }

    public String createNewSession(String sessionid, User user, long secondsDuration) {
        User userResult = userRepo.findByEmail(user.getEmail());
        boolean correctPassword = userResult != null && Integer.toString(user.getPassword().hashCode()).equals(userResult.getPassword());
        if (correctPassword) {
            sessionRepo.deleteByUseremail(user.getEmail());
            Session newSession = sessionRepo.save(new Session(sessionid, user.getEmail(), LocalDateTime.now().plusSeconds(secondsDuration)));
            return newSession.getId();
        }
        return null;
    }
}
