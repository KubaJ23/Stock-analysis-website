package com.stockViewer.stockViewer.repositories;

import com.stockViewer.stockViewer.models.Session;
import com.stockViewer.stockViewer.models.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SessionRepo extends MongoRepository<Session, String> {
    public Session findByUseremail(String email);
    public void deleteByUseremail(String email);
}
