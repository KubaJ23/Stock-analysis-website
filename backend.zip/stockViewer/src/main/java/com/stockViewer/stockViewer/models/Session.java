package com.stockViewer.stockViewer.models;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Document(collection = "usersessions")
public class Session {
    @Id
    private String id;
    private String useremail;
    private LocalDateTime expiryDate;

    public Session() {
    }

    public Session(String useremail, LocalDateTime expiryDate) {
        this.useremail = useremail;
        this.expiryDate = expiryDate;
    }

    public Session(String id, String useremail, LocalDateTime expiryDate) {
        this(useremail, expiryDate);
        this.id = id;
    }
}
