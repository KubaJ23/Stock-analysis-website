package com.stockViewer.stockViewer.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyProfile {
    private String symbol;
    private double price;
    private long mktCap;
    private String companyName;
    private String currency;
    private String exchange;
    private String industry;
    private String website;
    private String description;
    private String ceo;
    private String country;
    private String fullTimeEmployees;
    private String address;
    private String city;
    private String state;
    private String image;
    private String ipoDate;

//    {
//        "symbol": "WE",
//            "price": 0.8355,
//            "beta": 2.089,
//            "volAvg": 4481668,
//            "mktCap": 44079977,
//            "lastDiv": 0,
//            "range": "0.82-130.8",
//            "changes": -0.2745,
//            "companyName": "WeWork Inc.",
//            "currency": "USD",
//            "cik": "0001813756",
//            "isin": "US96209A4013",
//            "cusip": "96209A104",
//            "exchange": "New York Stock Exchange",
//            "exchangeShortName": "NYSE",
//            "industry": "Real Estate - Services",
//            "website": "https://www.wework.com",
//            "description": "WeWork Inc. provides flexible workspace solutions to individuals and organizations worldwide. The company offers workstation, private office, and customized floor solutions; and various amenities and services, such as private phone booths, internet, high-speed business printers and copiers, mail and package handling, front desk services, off-peak building access, common areas, and daily enhanced cleaning solutions. It also offers various value-add services; business and technical service solutions, including professional employer organization and payroll services, remote workforce solutions, human resources benefits, dedicated bandwidth, and IT equipment co-location solutions. In addition, the company offers workspace management solutions, which enable landlords and operators to power flexible spaces and provide direct access to an established customer base. As of December 31, 2021, its real estate portfolio includes 756 locations. WeWork Inc. was founded in 2010 and is headquartered in New York, New York.",
//            "ceo": "Mr. David M. Tolley",
//            "sector": "Real Estate",
//            "country": "US",
//            "fullTimeEmployees": "4300",
//            "phone": "646 389 3922",
//            "address": "575 Lexington Avenue",
//            "city": "New York",
//            "state": "NY",
//            "zip": "10022",
//            "dcfDiff": null,
//            "dcf": 0,
//            "image": "https://financialmodelingprep.com/image-stock/WE.png",
//            "ipoDate": "2021-10-21",
//            "defaultImage": false,
//            "isEtf": false,
//            "isActivelyTrading": false,
//            "isAdr": false,
//            "isFund": false
//    }
}
