package com.stockViewer.stockViewer.models;

import lombok.Data;

@Data
public class ChangePasswordForm {
    private String email;
    private String oldpassword;
    private String newpassword;
}
