package com.stockViewer.stockViewer;

import com.stockViewer.stockViewer.models.Session;
import com.stockViewer.stockViewer.models.User;
import com.stockViewer.stockViewer.repositories.SessionRepo;
import com.stockViewer.stockViewer.repositories.UserRepo;
import com.stockViewer.stockViewer.services.LoginService;
import com.stockViewer.stockViewer.services.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.time.LocalDateTime;

@Component
public class RequestProcessor implements HandlerInterceptor {

    @Autowired
    SessionRepo sessionRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    LoginService loginService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            System.out.println("A user has been rejected - no cookie");
            response.setStatus(401);
            return false;
        }

        for (Cookie cookie : cookies) {
            if (!"sessionid".equalsIgnoreCase(cookie.getName())) {
                continue;
            }

            Session session = sessionRepo.findById(cookie.getValue()).orElse(null);
            // check if session is valid
            if (session == null) {
                System.out.println("Session not found, request rejected");
                response.setStatus(401);
                return false;
            }
            if (session.getExpiryDate().isBefore(LocalDateTime.now())) {
                System.out.println("Session expired, request rejected");
                response.setStatus(401);
                return false;
            }
            User requestingUser = userRepo.findByEmail(session.getUseremail());
            if (requestingUser == null) {
                System.out.println("User corresponding to session not found, request rejected");
                response.setStatus(401);
                return false;
            }

            // update expiration time of cookie
//            loginService.createNewSession(session.getId(), requestingUser, Global.cookieLifeDurationSeconds);

            request.setAttribute("requestingUser", requestingUser);
            System.out.println("-----------------------------------------------");
            System.out.println(requestingUser.getEmail() + " user has been granted access to the API");
            return true;
        }
        System.out.println("Unknown error has occurred with request: " + request);
        return false;
    }
}
