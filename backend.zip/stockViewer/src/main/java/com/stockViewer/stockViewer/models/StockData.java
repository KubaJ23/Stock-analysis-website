package com.stockViewer.stockViewer.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.SimpleDateFormat;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockData {
    private String date;
    private double open;
    private double high;
    private double low;
    private double close;
    private double change;
    private double changePercent;

//    "date": "2024-07-05",
//            "open": 221.65,
//            "high": 226.45,
//            "low": 221.65,
//            "close": 226.34,
//            "adjClose": 226.34,
//            "volume": 60340176,
//            "unadjustedVolume": 60340176,
//            "change": 4.69,
//            "changePercent": 2.12,
//            "vwap": 224.0225,
//            "label": "July 05, 24",
//            "changeOverTime": 0.0212
}
