package com.stockViewer.stockViewer;

public class Global {
    public final static long cookieLifeDurationSeconds = 60000;
//    public final static String frontendDomain = "http://localhost:5173";
    public final static String frontendDomain = "http://192.168.0.7:5173";
    // paste your api key here to access the stock data from the api provider 'financialmodelingprep.com'
    public final static String apiKey = "";
    public final static String stockApi = "https://financialmodelingprep.com";
}
