package com.stockViewer.stockViewer.controllers;

import com.stockViewer.stockViewer.models.SignUpForm;
import com.stockViewer.stockViewer.models.User;
import com.stockViewer.stockViewer.services.LoginService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;

import com.stockViewer.stockViewer.Global;

@RestController
@CrossOrigin(origins = Global.frontendDomain, allowCredentials = "true")
public class LoginController {
    @Autowired
    LoginService loginService;

    @PostMapping(value = "/signup", consumes = "application/json")
    public void signUp(@RequestBody SignUpForm form, HttpServletResponse response) throws IOException {
        Boolean userSaved = loginService.saveUser(new User(form.getEmail(), form.getPassword(), new ArrayList<>()));
        if (userSaved) {
            System.out.printf("User Saved: (email) %s, (password) %s\n", form.getEmail(), form.getPassword());
            response.setStatus(200);
        } else {
            System.out.printf("User not saved: '%s', '%s'\n", form.getEmail(), form.getPassword());
            response.setStatus(403);
        }
    }


    @PostMapping(value = "/login", consumes = "application/json")
    public void login(@RequestBody SignUpForm form, HttpServletResponse response) throws IOException {

        String sessionID = loginService.createNewSession(null, new User(form.getEmail(), form.getPassword(), new ArrayList<>()), Global.cookieLifeDurationSeconds);
        if (sessionID == null) {
            System.out.printf("User session not created- email: %s, password: %s\n", form.getEmail(), form.getPassword());
            response.setStatus(401);
        } else {
            Cookie cookie = new Cookie("sessionid", sessionID);
            cookie.setSecure(false);
            cookie.setPath("/");
            cookie.setMaxAge((int) Global.cookieLifeDurationSeconds); // 1 day
            response.addCookie(cookie);

            System.out.printf("User session created: (email) %s, (password) %s\n", form.getEmail(), form.getPassword());

            response.setStatus(200);
        }
    }
}
