package com.stockViewer.stockViewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockViewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockViewerApplication.class, args);
	}

}
