package com.stockViewer.stockViewer.models;

import lombok.Data;

@Data
public class CompanySearchItem {
    private String symbol;
    private String name;
    private String currency;
    private String stockExchange;
    private String exchangeShortName;
//    "symbol": "AA",
//            "name": "Alcoa Corporation",
//            "currency": "USD",
//            "stockExchange": "New York Stock Exchange",
//            "exchangeShortName": "NYSE"
}
