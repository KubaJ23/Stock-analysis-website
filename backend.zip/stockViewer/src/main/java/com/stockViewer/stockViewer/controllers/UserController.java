package com.stockViewer.stockViewer.controllers;

import com.stockViewer.stockViewer.Global;
import com.stockViewer.stockViewer.models.*;
import com.stockViewer.stockViewer.repositories.UserRepo;
import com.stockViewer.stockViewer.services.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.aop.scope.ScopedProxyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = Global.frontendDomain, allowCredentials = "true")
public class UserController {
    @Autowired
    UserService userService;

    @GetMapping(value="/check-session")
    public ResponseEntity<String> checkSession(){
        // if the request has reached this point, then the session is valid
        return ResponseEntity.status(200).body("Your session is valid :)");
    }

    @PutMapping(value = "/change-password", consumes = "application/json")
    public void changePassword(@RequestBody ChangePasswordForm changePasswordForm, HttpServletRequest request, HttpServletResponse response) {
        User user = (User) request.getAttribute("requestingUser");
        if (changePasswordForm.getEmail() == null || !userService.changeUserPassword(changePasswordForm)) {
            System.out.printf("User password not changed: email: %s, oldP: %s, newP: %s\n", changePasswordForm.getEmail(), changePasswordForm.getOldpassword(), changePasswordForm.getNewpassword());
            response.setStatus(401);
            return;
        }
        System.out.printf("changing password for user '%s' from '%s' to '%s'\n", user.getEmail(), user.getPassword(), changePasswordForm.getNewpassword());
    }

    @GetMapping("/email")
    public String getUserEmail(HttpServletRequest request) {
        String userEmail = ((User) request.getAttribute("requestingUser")).getEmail();
        System.out.printf("got email for user: '%s'\n", userEmail);
        return userEmail;
    }

    @GetMapping("/stock-list")
    public List<String> getStockList(HttpServletRequest request) {
        System.out.println("retrieving your stock list...");
        return UserService.getUserStockList((User) request.getAttribute("requestingUser"));
    }

    @GetMapping("/info/{stockName}")
    public ResponseEntity<StockHistoricalPrice> getStockInfo(@PathVariable(name = "stockName") String stockName) throws URISyntaxException, IOException, InterruptedException {
//        System.out.println("getting stock info on " + stockName + "...");
//        StockHistoricalPrice historicalPrice = new StockHistoricalPrice("ABCD", List.of(
//                new StockData("2023-07-01", 150.0, 155.0, 149.0, 154.0, 4.0, 2.67),
//                new StockData("2023-07-02", 154.0, 157.0, 153.0, 156.0, 2.0, 1.30),
//                new StockData("2023-07-03", 156.0, 160.0, 155.0, 158.0, 2.0, 1.28),
//                new StockData("2023-07-04", 158.0, 162.0, 157.0, 161.0, 3.0, 1.90),
//                new StockData("2023-07-05", 161.0, 165.0, 160.0, 164.0, 3.0, 1.86),
//                new StockData("2023-07-06", 164.0, 167.0, 163.0, 166.0, 2.0, 1.22),
//                new StockData("2023-07-07", 166.0, 170.0, 165.0, 169.0, 3.0, 1.81),
//                new StockData("2023-07-08", 169.0, 173.0, 168.0, 172.0, 3.0, 1.78),
//                new StockData("2023-07-09", 172.0, 175.0, 171.0, 174.0, 2.0, 1.16),
//                new StockData("2023-07-10", 174.0, 178.0, 173.0, 177.0, 3.0, 1.72)
//        ));
//        return new ResponseEntity<>(historicalPrice, HttpStatus.OK);

        System.out.println("getting stock info on " + stockName + "...");
        StockHistoricalPrice historical = userService.getStockHistoricalPrice(stockName);
        return new ResponseEntity<>(historical, historical == null ? HttpStatus.NOT_FOUND : HttpStatus.OK);
    }

    @PostMapping("add-stock/{stockName}")
    public void addStock(@PathVariable(name = "stockName") String stockName, HttpServletRequest request) {
        // currently we don't check if stock is real/valid
        userService.addStockForUser((User) request.getAttribute("requestingUser"), stockName);
        System.out.println("adding stock " + stockName + "...");
    }

    @DeleteMapping("delete-stock/{stockName}")
    public void deleteStock(@PathVariable(name = "stockName") String stockName, HttpServletRequest request) {
        // currently we don't check if stock is real/valid
        userService.deleteStockForUser((User) request.getAttribute("requestingUser"), stockName);
        System.out.println("deleting stock " + stockName + "...");
    }

    @GetMapping("search-stocks/{stockName}")
    public List<CompanySearchItem> searchStock(@PathVariable(name = "stockName") String stockName, HttpServletRequest request) throws URISyntaxException, IOException, InterruptedException {
        System.out.printf("Searching for stock '%s'...\n", stockName);
        return userService.searchCompany(stockName);
    }

    @DeleteMapping("/logout")
    public void logout(HttpServletRequest request, HttpServletResponse response) {
        User user = (User) request.getAttribute("requestingUser");
        boolean succ = userService.deleteSession(user);
        System.out.println("User logged out: " + user.getEmail());
        response.setStatus(succ ? 200 : 404);
    }

    @GetMapping("company-profile/{stockName}")
    public ResponseEntity<CompanyProfile> getCompanyProfile(@PathVariable(name = "stockName") String stockName) throws URISyntaxException, IOException, InterruptedException {
//        System.out.println("Company profile found on " + stockName);
//        int num = (int) ((new Random()).nextDouble() * 4);
//        List<CompanyProfile> profiles = List.of(new CompanyProfile(
//                        "AAPL", 145.86, 2420000000000L, "Apple Inc.", "USD", "NASDAQ",
//                        "Technology", "https://www.apple.com", "Apple Inc. designs, manufactures, and markets smartphones, personal computers, tablets, wearables, and accessories worldwide.",
//                        "Tim Cook", "USA", "147,000", "One Apple Park Way", "Cupertino", "CA",
//                        "https://logo.clearbit.com/apple.com", "1980-12-12"
//                ), new CompanyProfile(
//                        "GOOGL", 2728.80, 1820000000000L, "Alphabet Inc.", "USD", "NASDAQ",
//                        "Technology", "https://www.abc.xyz", "Alphabet Inc. is a holding company, which engages in the business of acquisition and operation of different companies.",
//                        "Sundar Pichai", "USA", "156,500", "1600 Amphitheatre Parkway", "Mountain View", "CA",
//                        "https://logo.clearbit.com/abc.xyz", "2004-08-19"
//                ), new CompanyProfile(
//                        "AMZN", 3344.94, 1685000000000L, "Amazon.com, Inc.", "USD", "NASDAQ",
//                        "Consumer Cyclical", "https://www.amazon.com", "Amazon.com, Inc. engages in the retail sale of consumer products and subscriptions in North America and internationally.",
//                        "Andy Jassy", "USA", "1,298,000", "410 Terry Avenue North", "Seattle", "WA",
//                        "https://logo.clearbit.com/amazon.com", "1997-05-15"
//                ), new CompanyProfile(
//                        "MSFT", 299.79, 2250000000000L, "Microsoft Corporation", "USD", "NASDAQ",
//                        "Technology", "https://www.microsoft.com", "Microsoft Corporation develops, licenses, and supports software, services, devices, and solutions worldwide.",
//                        "Satya Nadella", "USA", "181,000", "One Microsoft Way", "Redmond", "WA",
//                        "https://logo.clearbit.com/microsoft.com", "1986-03-13"
//                )
//        );
//        return new ResponseEntity<>(profiles.get(num), HttpStatus.OK);
        CompanyProfile companyProfile = userService.getCompanyProfile(stockName).getFirst();
        if (companyProfile == null) {
            System.out.println("Company profile not found for a user");
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
        System.out.println("Company profile found on " + stockName);
        return new ResponseEntity<>(companyProfile, HttpStatus.OK);
    }
}
