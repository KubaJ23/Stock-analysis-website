package com.stockViewer.stockViewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockViewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
